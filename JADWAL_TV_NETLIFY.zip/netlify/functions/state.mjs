// Penyimpanan bersama jadwal TV (foto, nama coach, pengaturan) memakai Netlify Blobs.
import { getStore } from "@netlify/blobs";

const J = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });

export default async (req) => {
  const store = getStore({ name: "jadwal-tv", consistency: "strong" });
  if (req.method === "GET") {
    const s = await store.get("state", { type: "json" });
    if (!s) return J({ ok: true, empty: true, rev: 0 });
    const since = new URL(req.url).searchParams.get("since");
    if (since && since === String(s.rev)) return J({ ok: true, same: true, rev: s.rev });
    return J({ ok: true, ...s });
  }
  if (req.method === "PUT") {
    // Opsional: isi variabel lingkungan EDIT_PIN di Netlify untuk mewajibkan PIN saat mengedit.
    const pin = (typeof Netlify !== "undefined" && Netlify.env.get("EDIT_PIN")) || process.env.EDIT_PIN;
    if (pin && req.headers.get("x-pin") !== pin) return J({ error: "pin" }, 401);
    const patch = await req.json();
    const s = (await store.get("state", { type: "json" })) || { cfg: null, coaches: null, photos: {} };
    if (patch.cfg) s.cfg = patch.cfg;
    if (patch.coaches) s.coaches = patch.coaches;
    if (patch.photos) {
      s.photos = s.photos || {};
      for (const [k, v] of Object.entries(patch.photos)) {
        if (v === null) delete s.photos[k];
        else s.photos[k] = v;
      }
    }
    s.rev = Date.now();
    await store.setJSON("state", s);
    return J({ ok: true, rev: s.rev });
  }
  return J({ error: "method" }, 405);
};

export const config = { path: "/api/state" };
